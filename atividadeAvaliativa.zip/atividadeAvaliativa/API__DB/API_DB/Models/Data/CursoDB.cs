﻿using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using System.Data.SqlClient;

namespace API_DB.Models.Data
{
    public class CursoDB
    {
        private readonly IConexao _conexao;
        public CursoDB(IConexao conexao)
        {
            _conexao = conexao;
        }

        public async Task<List<CursoViewModel>> listarCursos()
        {
            List<CursoViewModel> cursos = new List<CursoViewModel>();

            using (SqlConnection conn = _conexao.getConexao())
            {

                string query = "Select * from tbCursos";
                SqlCommand command = new SqlCommand(query, conn);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        // Obter os dados e criar um objeto Aluno
                        CursoViewModel cursoAux = new CursoViewModel();
                        cursoAux.Curso = reader["Curso"].ToString();
                        cursoAux.CargaHoraria = Int32.Parse(reader["CargaHoraria"].ToString());
                        cursoAux.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        cursoAux.Sigla = reader["Sigla"].ToString();

                        // Adicionando o novo Aluno na lista
                        cursos.Add(cursoAux);
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return cursos;
        }
        public async Task<CursoViewModel> obterCursoPorId(int Id)
        {
            CursoViewModel curso = null;
            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "select * from tbCursos where IdCurso = @Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);
                conn.Open();
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        curso = new CursoViewModel();
                        curso.Curso = reader["Curso"].ToString();
                        curso.CargaHoraria = Int32.Parse(reader["CargaHoraria"].ToString());
                        curso.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        curso.Sigla = reader["Sigla"].ToString();
                    }
                }
                conn.Close();
            }
            return curso;
        }
        public async Task<CursoViewModel> obterCurso(CursoInputModel curso)
        {
            CursoViewModel cursoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Select Top 1 * from tbCursos" +
                               "Where Curso = @Curso And Sigla = @Sigla " +
                               "Order By IdCurso Desc";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Sigla", curso.Sigla);
                command.Parameters.AddWithValue("@Curso", curso.Curso);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Usando um objeto DataReader para ler os dados do banco
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    // Enquanto conseguir ler algum dado do banco...
                    while (reader.Read())
                    {
                        cursoAux = new CursoViewModel();

                        // Obter os dados e criar um objeto Aluno
                        cursoAux.IdCurso = Int32.Parse(reader["IdCurso"].ToString());
                        cursoAux.Curso = reader["Curso"].ToString();
                        cursoAux.Sigla = reader["Sigla"].ToString();
                        cursoAux.CargaHoraria = Int32.Parse(reader["CargaHoraria"].ToString());
                    }
                }

                // Fechando a conexão com o banco
                conn.Close();
            }

            return cursoAux;
        }
        public async Task<CursoViewModel> insertCurso(CursoInputModel curso)
        {
            CursoViewModel cursoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "insert into tbCursos (IdCurso, Sigla, Curso, CargaHoraria) values (Select max(IdCurso)+1 from tbCursos), @Sigla, @Curso, @CargaHoraria";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Sigla", curso.Sigla);
                command.Parameters.AddWithValue("@Curso", curso.Curso);
                command.Parameters.AddWithValue("@CargaHoraria", curso.CargaHoraria);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            cursoAux = await obterCurso(curso);
            return cursoAux;
        }
        public async Task<CursoViewModel> updateCurso(int Id, CursoInputModel curso)
        {
            CursoViewModel cursoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "update tbCursos set Sigla = @Sigla, Curso = @Curso, CargaHoraria = @CargaHoraria where IdCurso = @IdCurso";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);
                command.Parameters.AddWithValue("@Sigla", curso.Sigla);
                command.Parameters.AddWithValue("@Curso", curso.Curso);
                command.Parameters.AddWithValue("@CargaHoraria", curso.CargaHoraria);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            cursoAux = await obterCurso(curso);
            return cursoAux;
        }
        public async Task<CursoViewModel> deleteCurso(int Id)
        {

            CursoViewModel cursoAux = await obterCursoPorId(Id);

            using (SqlConnection conn = _conexao.getConexao())
            {
                // Criando a instrução SQL e o objeto command para executá-la
                string query = "Delete From tbCursos Where IdCurso=@Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);

                // Abrindo a conexão com o banco de dados
                conn.Open();

                // Executando o comando
                await command.ExecuteNonQueryAsync();

                // Fechando a conexão com o banco
                conn.Close();
            }

            return cursoAux;
        }
    }
}

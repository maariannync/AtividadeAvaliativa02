﻿using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using System.Data.SqlClient;

namespace API_DB.Models.Data
{
    public class TipoAlunoDB
    {
        private readonly IConexao _conexao;

        public TipoAlunoDB(IConexao conexao)
        {
            _conexao = conexao;
        }

        public async Task<List<TipoAlunoViewModel>> listarTipoAluno()
        {
            List<TipoAlunoViewModel> tipoAlunos = new List<TipoAlunoViewModel>();
            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "select * from tbTipoAluno";
                SqlCommand command = new SqlCommand(query, conn);
                conn.Open();
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        TipoAlunoViewModel tipoAluno = new TipoAlunoViewModel();
                        tipoAluno.IdTipoAluno = Int32.Parse(reader["IdTipo"].ToString());
                        tipoAluno.TipoAluno = reader["Tipo"].ToString();
                        tipoAlunos.Add(tipoAluno);
                    }
                }
                conn.Close();
            }

            return tipoAlunos;
        }

        public async Task<TipoAlunoViewModel> obterTipoAlunoPorId(int Id)
        {
            TipoAlunoViewModel tipoAluno = null;

            using (SqlConnection conn = _conexao.getConexao())
            {             
                string query = "Select * from tbTipoAluno Where IdTipo = @Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);
                conn.Open();
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        tipoAluno = new TipoAlunoViewModel();
                        tipoAluno.IdTipoAluno = Int32.Parse(reader["IdTipo"].ToString());
                        tipoAluno.TipoAluno = reader["Tipo"].ToString();
                    }
                }
                conn.Close();
            }
            return tipoAluno;
        }

        public async Task<TipoAlunoViewModel> obterTipoAluno(TipoAlunoInputModel aluno)
        {
            TipoAlunoViewModel tipoAlunoAux = null;

            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Select Top 1 * from tbTipoAluno" +
                               "Where idTipo = @Tipo" +
                               "Order By IdAluno Desc";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Tipo", tipoAlunoAux.IdTipoAluno);
                conn.Open();
                using (SqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (reader.Read())
                    {
                        tipoAlunoAux = new TipoAlunoViewModel();
                        tipoAlunoAux.IdTipoAluno = Int32.Parse(reader["IdTipo"].ToString());
                        tipoAlunoAux.TipoAluno = reader["Tipo"].ToString();
                    }
                }
                conn.Close();
            }
            return tipoAlunoAux;
        }

        public async Task<TipoAlunoViewModel> insertTipoAluno(TipoAlunoInputModel tipoAluno)
        {
            TipoAlunoViewModel tipoAlunoAux = null;
            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Insert Into tbTipoAluno (IdTipoAluno, Tipo) " +
                               "Values (" +
                                  "(Select Max(IdTipoAluno)+1 From tbTipoAluno), @Tipo" +
                               ")";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Tipo", tipoAlunoAux.TipoAluno);
                conn.Open();
                await command.ExecuteNonQueryAsync();
                conn.Close();
            }

            tipoAlunoAux = await obterTipoAluno(tipoAluno);
            return tipoAlunoAux;
        }

        public async Task<TipoAlunoViewModel> updateTipoAluno(int Id, TipoAlunoInputModel tipoAluno)
        {
            TipoAlunoViewModel tipoAlunoAux = null;
            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Update tbTipoAluno Set IdTipo=@Id, TipoAluno=@Tipo, " +
                                  "DataNascimento=@DataNasc, IdTipoAluno=@IdTipo " +
                                  "Where IdTipo=@Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);
                command.Parameters.AddWithValue("@Tipo", tipoAluno.TipoAluno);
                conn.Open();
                await command.ExecuteNonQueryAsync();
                conn.Close();
            }
            tipoAlunoAux = await obterTipoAluno(tipoAluno);
            return tipoAlunoAux;
        }

        public async Task<TipoAlunoViewModel> deleteTipoAluno(int Id)
        {
            TipoAlunoViewModel tipoAlunoAux = await obterTipoAlunoPorId(Id);
            using (SqlConnection conn = _conexao.getConexao())
            {
                string query = "Delete From tbTipoAluno Where IdTipoAluno=@Id";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@Id", Id);
                conn.Open();
                await command.ExecuteNonQueryAsync();
                conn.Close();
            }
            return tipoAlunoAux;
        }
    }
}

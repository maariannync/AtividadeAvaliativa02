﻿namespace API_DB.Models.ViewModels
{
    public class TipoAlunoViewModel
    {
        public int IdTipoAluno { get; set; }
        public string TipoAluno { get; set; }
    }
}

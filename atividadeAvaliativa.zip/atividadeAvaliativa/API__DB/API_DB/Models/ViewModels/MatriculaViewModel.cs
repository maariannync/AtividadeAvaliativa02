﻿namespace API_DB.Models.ViewModels
{
    public class MatriculaViewModel
    {
        public int IdMatricula {  get; set; }
        public int IdAluno { get; set; }
        public int IdCurso { get; set; }
        public DateOnly DataMatricula { get; set; }
    }
}

﻿namespace API_DB.Models.ViewModels
{
    public class CursoViewModel
    {
        public int IdCurso { get; set; }
        public string Curso { get; set; }
        public string Sigla { get; set; }
        public int CargaHoraria { get; set; }
    }
}

﻿namespace API_DB.Models.InputModels
{
    public class TipoAlunoInputModel
    {
        public int IdTipoAluno { get; set; }
        public string TipoAluno { get; set; }
    }
}

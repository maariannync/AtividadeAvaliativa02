﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class AlunoController : ControllerBase
    {
        private readonly ILogger<AlunoController> _logger;
        private readonly AlunoDB _alunoDB;

        public AlunoController(ILogger<AlunoController> logger, AlunoDB alunoDB)
        {
            _logger = logger;
            _alunoDB = alunoDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AlunoViewModel>>> getAlunos()
        {
            try
            {
                var dados = await _alunoDB.listarAlunos();
                if (dados != null) 
                    return Ok(dados);
                else 
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter!");
            }
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<AlunoViewModel>> getAlunoById([FromRoute] int Id)
        {
            try
            {
                var dados = await _alunoDB.obterAlunoPorId(Id);
                if (dados != null)
                    return Ok(dados);
                else 
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível encontrar!");
            }
        }

        [HttpPost]
        public async Task<ActionResult<AlunoViewModel>> InsertAluno(
            [FromBody] AlunoInputModel aluno
        )
        {
            try
            {
                var dados = await _alunoDB.insertAluno(aluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível inserir!");
            }
        }

        [HttpPut("{Id}")]
        public async Task<ActionResult<AlunoViewModel>> UpdateAluno(
            [FromRoute] int Id, [FromBody] AlunoInputModel aluno
        )
        {
            try
            {
                var dados = await _alunoDB.updateAluno(Id, aluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível atualizar?");
            }
        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<AlunoViewModel>> Delete([FromRoute] int Id)
        {
            try
            {
                var dados = await _alunoDB.deleteAluno(Id);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível excluir!");
            }
        }

    }
}

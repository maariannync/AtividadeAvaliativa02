﻿using API_DB.Models.Data;
using API_DB.Models.InputModels;
using API_DB.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TipoAlunoController : ControllerBase
    {
        private readonly ILogger<TipoAlunoController> _logger;
        private readonly TipoAlunoDB _tipoAlunoDB;

        public TipoAlunoController(ILogger<TipoAlunoController> logger, TipoAlunoDB tipoAlunoDB)
        {
            _logger = logger;
            _tipoAlunoDB = tipoAlunoDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<TipoAlunoViewModel>>> getTipoAluno()
        {
            try
            {
                var dados = await _tipoAlunoDB.listarTipoAluno();
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter a lista de tipos!");
            }
        }


        [HttpGet("{Id}")]
        public async Task<ActionResult<TipoAlunoViewModel>> getAlunoById([FromRoute] int Id)
        {
            try
            {
                var dados = await _tipoAlunoDB.obterTipoAlunoPorId(Id);
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível encontrar o aluno!");
            }
        }

        [HttpPost]
        public async Task<ActionResult<TipoAlunoViewModel>> InsertTipoAluno(
            [FromBody] TipoAlunoInputModel aluno
        )
        {
            try
            {
                var dados = await _tipoAlunoDB.insertTipoAluno(aluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível inserir o aluno!");
            }
        }

        [HttpPut("{Id}")]
        public async Task<ActionResult<TipoAlunoViewModel>> UpdateTipoAluno(
            [FromRoute] int Id, [FromBody] TipoAlunoInputModel aluno
        )
        {
            try
            {
                var dados = await _tipoAlunoDB.updateTipoAluno(Id, aluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível atualizar o aluno!");
            }
        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult<AlunoViewModel>> DeleteTipoAluno([FromRoute] int Id)
        {
            try
            {
                var dados = await _tipoAlunoDB.deleteTipoAluno(Id);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível excluir o aluno!");
            }
        }
    }
}

﻿using API_DB.Models.Data;
using API_DB.Models.ViewModels;
using API_DB.Models.InputModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace API_DB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MatriculaController : ControllerBase
    {
        private readonly ILogger<MatriculaController> _logger;
        private readonly MatriculaDB _matriculaDB;

        public MatriculaController(ILogger<MatriculaController> logger, MatriculaDB matriculaDB)
        {
            _logger = logger;
            _matriculaDB = matriculaDB;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<MatriculaViewModel>>> getMatricula()
        {
            try
            {
                var dados = await _matriculaDB.listarMatricula();
                if (dados != null)
                    return Ok(dados);
                else
                    return NoContent();
            }
            catch (Exception)
            {
                return BadRequest("Não foi possível obter as matriculas!");
            }
        }

        [HttpPost]
        public async Task<ActionResult<MatriculaViewModel>> InsertMatricula(
           [FromBody] MatriculaInputModel matricula
       )
        {
            try
            {
                var dados = await _matriculaDB.insertMatricula(matricula);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível inserir as matriculas!");
            }
        }
        [HttpDelete("{IdCurso}/{IdAluno}")]
        public async Task<ActionResult<MatriculaViewModel>> Delete([FromRoute] int IdCurso, [FromRoute] int IdAluno)
        {
            try
            {
                var dados = await _matriculaDB.deleteMatricula(IdCurso, IdAluno);
                return Ok(dados);
            }
            catch (Exception)
            {
                return UnprocessableEntity("Não foi possível excluir as matriculas!");
            }
        }
    }  
}
